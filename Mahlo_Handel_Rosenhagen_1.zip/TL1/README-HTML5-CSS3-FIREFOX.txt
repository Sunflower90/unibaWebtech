﻿Optimiert auf Firefox
=====================

Was ist HTML5

<figure> - Tag verwendet (auf Seite Kleidung, Kaffee, Sonstige)
<aside> - Auf jeder Seite verwendet
<nav> - auf jeder Seite verwendet
<footer> - auf jeder Seite verwendet
<article> - auf Allgemeines und Unterseiten (und weiteren Seiten)
<section> - auf Allgemeines und Unterseiten (und weiteren Seiten)
<audio> - auf Kaffee

Was ist CSS 3

- runde Ecken
- FlexBox-Layout

Sonstige Anforderungen:
- Breadcrumbs in der Navigation
- Logo und Überschrift
- Mindestens 3 externe Links
- Geforderte Seitenanzahl
